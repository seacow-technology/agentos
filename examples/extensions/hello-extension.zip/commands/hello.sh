#!/bin/bash
# Hello extension command handler

NAME="${1:-World}"

echo "🎉 Hello, $NAME!"
echo ""
echo "This is a minimal extension example for AgentOS."
echo "Extension ID: demo.hello"
echo "Version: 0.1.0"
echo ""
echo "To learn more, see: /extensions/demo.hello"
