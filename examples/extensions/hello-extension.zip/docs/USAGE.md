# Hello Extension

A minimal example extension for AgentOS.

## Overview

This extension demonstrates:
- Basic extension structure
- Minimal installation plan
- Slash command declaration
- Usage documentation

## Usage

Simply type `/hello` in the chat to see a greeting message.

### Examples

**Basic greeting:**
```
/hello
```
Output: "Hello, World!"

**Custom greeting:**
```
/hello AgentOS
```
Output: "Hello, AgentOS!"

## Implementation Details

### Installation

The installation plan performs these steps:
1. Detect platform (linux/darwin/win32)
2. Write configuration to store
3. Verify `echo` command exists
4. Test the installation

### Commands

The `/hello` command accepts an optional name parameter and displays:
- A greeting message
- Extension metadata
- Usage information

### Files

- `manifest.json` - Extension metadata
- `install/plan.yaml` - Installation plan
- `commands/commands.yaml` - Command definitions
- `commands/hello.sh` - Command implementation
- `docs/USAGE.md` - This documentation

## Requirements

- No external dependencies
- Works on all platforms (linux, darwin, win32)

## Configuration

This extension has no required configuration.

## Troubleshooting

If the `/hello` command doesn't work:
1. Check that the extension is installed: `/extensions list`
2. Check that the extension is enabled
3. View extension logs: `/extensions logs demo.hello`

## Support

For help, visit: https://github.com/agentos/extensions
